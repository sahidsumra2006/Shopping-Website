<?php
// Admin authentication check - include this at the top of all admin pages
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../admin_login.php?message=Please login to access admin panel');
    exit;
}
?>
