<?php
session_start();

// Destroy admin session
unset($_SESSION['admin_id']);
unset($_SESSION['admin_username']);
session_destroy();

// Redirect to admin login
header('Location: ../admin_login.php?message=Logged out successfully');
exit;
?>
