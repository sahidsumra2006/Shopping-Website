<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$order_id = isset($_POST['order_id']) ? (int)$_POST['order_id'] : 0;

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Get order details to verify ownership and status
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php?error=order_not_found');
    exit;
}

// Check if order can be cancelled (only pending orders)
if ($order['status'] != 'pending') {
    header('Location: orders.php?error=cannot_cancel');
    exit;
}

// Cancel the order
$stmt = $pdo->prepare("UPDATE orders SET status = 'cancelled', updated_at = NOW() WHERE id = ? AND user_id = ?");

if ($stmt->execute([$order_id, $_SESSION['user_id']])) {
    header('Location: orders.php?success=order_cancelled');
} else {
    header('Location: orders.php?error=cancel_failed');
}
exit;
?>
