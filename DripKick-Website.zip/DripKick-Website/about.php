<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - ShopEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1f2937;
            --accent-color: #8b5cf6;
            --light-gray: #f1f5f9;
            --medium-gray: #6b7280;
            --border-color: #d1d5db;
        }
        
        body {
            font-family: 'DM Sans', sans-serif;
            line-height: 1.6;
            color: var(--primary-color);
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--light-gray) 0%, #ffffff 100%);
            padding: 100px 0;
        }
        
        .section-padding {
            padding: 80px 0;
        }
        
        .card-custom {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background: #ffffff;
        }
        
        .card-custom:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.12);
        }
        
        .btn-primary-custom {
            background-color: var(--accent-color);
            border: none;
            border-radius: 12px;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .btn-primary-custom:hover {
            background-color: #7c3aed;
            transform: translateY(-2px);
        }
        
        .stats-section {
            background-color: var(--primary-color);
            color: white;
        }
        
        .stat-number {
            font-size: 3rem;
            font-weight: 700;
            color: var(--accent-color);
        }
        
        .team-img {
            border-radius: 16px;
            transition: transform 0.3s ease;
        }
        
        .team-img:hover {
            transform: scale(1.05);
        }
        
        .navbar-custom {
            background-color: #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-brand {
            font-family: 'Space Grotesk', sans-serif;
            font-weight: 700;
            font-size: 1.5rem;
            color: var(--primary-color) !important;
        }
        
        .nav-link {
            color: var(--primary-color) !important;
            font-weight: 500;
            transition: color 0.3s ease;
        }
        
        .nav-link:hover {
            color: var(--accent-color) !important;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <?php include 'includes/header.php'; ?>


    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 mb-4">About ShopEase</h1>
                    <p class="lead mb-4">We're passionate about bringing you the best shopping experience with carefully curated products, exceptional service, and unbeatable value.</p>
                    <button class="btn btn-primary-custom btn-lg">Explore Our Story</button>
                </div>
                <div class="col-lg-6">
                    <img src="/placeholder.svg?height=400&width=600" alt="About Us" class="img-fluid rounded-4">
                </div>
            </div>
        </div>
    </section>

    <!-- Mission Section -->
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="mb-4">Our Mission</h2>
                    <p class="lead">To revolutionize online shopping by providing a seamless, trustworthy, and delightful experience that connects customers with products they love while supporting sustainable business practices.</p>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-4 mb-4">
                    <div class="card card-custom h-100 p-4 text-center">
                        <div class="mb-3">
                            <i class="fas fa-heart fa-3x" style="color: var(--accent-color);"></i>
                        </div>
                        <h4>Customer First</h4>
                        <p>Every decision we make is centered around creating the best possible experience for our customers.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card card-custom h-100 p-4 text-center">
                        <div class="mb-3">
                            <i class="fas fa-leaf fa-3x" style="color: var(--accent-color);"></i>
                        </div>
                        <h4>Sustainability</h4>
                        <p>We're committed to environmental responsibility and supporting eco-friendly products and practices.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card card-custom h-100 p-4 text-center">
                        <div class="mb-3">
                            <i class="fas fa-star fa-3x" style="color: var(--accent-color);"></i>
                        </div>
                        <h4>Quality</h4>
                        <p>We carefully curate every product to ensure it meets our high standards for quality and value.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section -->
    <section class="stats-section section-padding">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-3 mb-4">
                    <div class="stat-number">50K+</div>
                    <h5>Happy Customers</h5>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-number">10K+</div>
                    <h5>Products</h5>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-number">99%</div>
                    <h5>Satisfaction Rate</h5>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-number">5</div>
                    <h5>Years Experience</h5>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center mb-5">
                    <h2>Meet Our Team</h2>
                    <p class="lead">The passionate individuals behind ShopEase who work tirelessly to bring you the best shopping experience.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card card-custom text-center p-4">
                        <img src="/placeholder.svg?height=200&width=200" alt="Sarah Johnson" class="team-img mx-auto mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                        <h5>Sarah Johnson</h5>
                        <p class="text-muted">CEO & Founder</p>
                        <p>Visionary leader with 10+ years in e-commerce, passionate about customer experience.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card card-custom text-center p-4">
                        <img src="/placeholder.svg?height=200&width=200" alt="Mike Chen" class="team-img mx-auto mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                        <h5>Mike Chen</h5>
                        <p class="text-muted">CTO</p>
                        <p>Tech innovator focused on building scalable, secure platforms that delight users.</p>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card card-custom text-center p-4">
                        <img src="/placeholder.svg?height=200&width=200" alt="Emily Rodriguez" class="team-img mx-auto mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                        <h5>Emily Rodriguez</h5>
                        <p class="text-muted">Marketing Director</p>
                        <p>Creative strategist who connects brands with customers through compelling storytelling.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="section-padding" style="background-color: var(--light-gray);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2 class="mb-4">Ready to Start Shopping?</h2>
                    <p class="lead mb-4">Join thousands of satisfied customers and discover your next favorite product today.</p>
                    <a href="shop.html" class="btn btn-primary-custom btn-lg me-3">Browse Products</a>
                    <a href="contact.html" class="btn btn-outline-dark btn-lg">Get in Touch</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Add animation on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe all cards
        document.querySelectorAll('.card-custom').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
    </script>
    
</body>
</html>
