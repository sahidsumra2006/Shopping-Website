<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=buy_now.php');
    exit;
}

$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
$quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;

if ($product_id <= 0 || $quantity <= 0) {
    header('Location: products.php');
    exit;
}

// Get product details
$stmt = $pdo->prepare("SELECT id, name, price, stock FROM products WHERE id = ? AND status = 'active'");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

// Check stock
if ($quantity > $product['stock']) {
    header('Location: product.php?id=' . $product_id . '&error=insufficient_stock');
    exit;
}

// Clear existing cart and add this product for immediate purchase
$_SESSION['cart'] = [];
$_SESSION['cart'][$product_id] = [
    'id' => $product['id'],
    'name' => $product['name'],
    'price' => $product['price'],
    'quantity' => $quantity
];

// Set buy now flag
$_SESSION['buy_now'] = true;

// Redirect to payment page
header('Location: payment.php');
exit;
?>
