<?php
session_start();
include 'config/database.php';
include 'includes/header.php';

// Handle cart updates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                $product_id = (int)$_POST['product_id'];
                $quantity = (int)$_POST['quantity'];
                
                if ($quantity > 0 && isset($_SESSION['cart'][$product_id])) {
                    $_SESSION['cart'][$product_id]['quantity'] = $quantity;
                }
                break;
                
            case 'remove':
                $product_id = (int)$_POST['product_id'];
                unset($_SESSION['cart'][$product_id]);
                break;
                
            case 'clear':
                $_SESSION['cart'] = [];
                break;
        }
    }
    header('Location: cart.php');
    exit;
}

$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$cart_total = 0;
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Shopping Cart</h2>
        <!-- Added cart item count display -->
        <span class="text-muted"><?php echo count($cart); ?> item(s) in cart</span>
    </div>
    
    <?php if (empty($cart)): ?>
    <div class="text-center py-5">
        <i class="fas fa-shopping-cart fa-3x text-muted mb-3"></i>
        <h4>Your cart is empty</h4>
        <p class="text-muted">Add some products to get started</p>
        <a href="products.php" class="btn btn-primary">Continue Shopping</a>
    </div>
    <?php else: ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <?php foreach ($cart as $product_id => $item): ?>
                    <?php $item_total = $item['price'] * $item['quantity']; $cart_total += $item_total; ?>
                    <div class="row align-items-center border-bottom py-3">
                        <div class="col-md-5">
                            <h6><?php echo htmlspecialchars($item['name']); ?></h6>
                            <p class="text-muted mb-0">$<?php echo number_format($item['price'], 2); ?> each</p>
                        </div>
                        <div class="col-md-3">
                            <!-- Enhanced quantity controls with better UX -->
                            <div class="input-group">
                                <button class="btn btn-outline-secondary btn-sm" type="button" onclick="updateQuantity(<?php echo $product_id; ?>, <?php echo $item['quantity'] - 1; ?>)">-</button>
                                <input type="number" class="form-control form-control-sm text-center" value="<?php echo $item['quantity']; ?>" min="1" onchange="updateQuantity(<?php echo $product_id; ?>, this.value)">
                                <button class="btn btn-outline-secondary btn-sm" type="button" onclick="updateQuantity(<?php echo $product_id; ?>, <?php echo $item['quantity'] + 1; ?>)">+</button>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <strong>$<?php echo number_format($item_total, 2); ?></strong>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeCartItem(<?php echo $product_id; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <button type="button" class="btn btn-outline-secondary" onclick="clearCart()">
                            <i class="fas fa-trash me-2"></i>Clear Cart
                        </button>
                        <a href="products.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h5>Order Summary</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <span>Subtotal:</span>
                        <span>$<?php echo number_format($cart_total, 2); ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Shipping:</span>
                        <span>$5.00</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span>Tax:</span>
                        <span>$<?php echo number_format($cart_total * 0.08, 2); ?></span>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between">
                        <strong>Total:</strong>
                        <strong>$<?php echo number_format($cart_total + 5 + ($cart_total * 0.08), 2); ?></strong>
                    </div>
                    
                    <div class="d-grid gap-2 mt-3">
                        <!-- Updated checkout button to redirect to payment page -->
                        <a href="payment.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-credit-card me-2"></i>Proceed to Payment
                        </a>
                        <a href="products.php" class="btn btn-outline-secondary">Continue Shopping</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
function updateQuantity(productId, quantity) {
    if (quantity < 1) return;
    
    const form = document.createElement('form');
    form.method = 'POST';
    form.style.display = 'none';
    
    const actionInput = document.createElement('input');
    actionInput.name = 'action';
    actionInput.value = 'update';
    
    const productInput = document.createElement('input');
    productInput.name = 'product_id';
    productInput.value = productId;
    
    const quantityInput = document.createElement('input');
    quantityInput.name = 'quantity';
    quantityInput.value = quantity;
    
    form.appendChild(actionInput);
    form.appendChild(productInput);
    form.appendChild(quantityInput);
    document.body.appendChild(form);
    form.submit();
}

function removeCartItem(productId) {
    if (confirm('Are you sure you want to remove this item from your cart?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';
        
        const actionInput = document.createElement('input');
        actionInput.name = 'action';
        actionInput.value = 'remove';
        
        const productInput = document.createElement('input');
        productInput.name = 'product_id';
        productInput.value = productId;
        
        form.appendChild(actionInput);
        form.appendChild(productInput);
        document.body.appendChild(form);
        form.submit();
    }
}

function clearCart() {
    if (confirm('Are you sure you want to clear your entire cart?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.style.display = 'none';
        
        const actionInput = document.createElement('input');
        actionInput.name = 'action';
        actionInput.value = 'clear';
        
        form.appendChild(actionInput);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

<?php include 'includes/footer.php'; ?>
