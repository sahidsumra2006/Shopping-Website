Admin Pannel :
Username=Admin
Password=Admin@123

AA Error Solve Karvani Chhe Parth Tare :
01. Badhi Product Na Name Change Kari Ne Eene Shoes Ma Convert Karvana
02. Image Add Nathi Thati Add Product Ma(Admin pannel) Ni Andar
03. Bdha Na Price Change Karvana chhe 
04. AboutUs Ane ContactUs Ni File Banavi Ne Eene Sarkhi Rite Add Karvani
05. Tamari Website Nu Description Badhu Like Name Change Ane Ee Badhu

Mane Lage Chhe Aa Bhadi Vastu Mate AI kaam Nai Aave Ane Aa Badhi Vastu Database Mathi Pan Change Karvi Padse
Toh Have Atlu Tare Karvanu Chhe Naim Eee Atlu Kari Ne Dai Didhu
