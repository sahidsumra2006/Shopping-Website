<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=order_details.php');
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit;
}

// Get order items
$stmt = $pdo->prepare("SELECT oi.*, p.name as product_name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$stmt->execute([$order_id]);
$order_items = $stmt->fetchAll();

// Parse shipping address
$shipping_address = json_decode($order['shipping_address'], true);

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Order Details</h2>
        <a href="orders.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Back to Orders
        </a>
    </div>
    
    <div class="row">
        <div class="col-lg-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Order Date:</strong> <?php echo date('F j, Y g:i A', strtotime($order['created_at'])); ?></p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-<?php 
                                    echo $order['status'] == 'delivered' ? 'success' : 
                                        ($order['status'] == 'cancelled' ? 'danger' : 'warning'); 
                                ?>">
                                    <?php echo ucfirst($order['status']); ?>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Payment Method:</strong> 
                                <span class="badge bg-<?php echo $order['payment_method'] == 'cod' ? 'warning' : 'info'; ?>">
                                    <?php echo strtoupper($order['payment_method']); ?>
                                </span>
                            </p>
                            <p><strong>Total Amount:</strong> $<?php echo number_format($order['total'], 2); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5>Order Items</h5>
                </div>
                <div class="card-body">
                    <?php foreach ($order_items as $item): ?>
                    <div class="row align-items-center border-bottom py-3">
                        <div class="col-md-2">
                            <img src="assets/images/products/<?php echo $item['image']; ?>" 
                                 alt="<?php echo htmlspecialchars($item['product_name']); ?>" 
                                 class="img-fluid rounded">
                        </div>
                        <div class="col-md-6">
                            <h6><?php echo htmlspecialchars($item['product_name']); ?></h6>
                            <p class="text-muted mb-0">$<?php echo number_format($item['price'], 2); ?> each</p>
                        </div>
                        <div class="col-md-2">
                            <span class="badge bg-secondary">Qty: <?php echo $item['quantity']; ?></span>
                        </div>
                        <div class="col-md-2 text-end">
                            <strong>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></strong>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h5>Shipping Address</h5>
                </div>
                <div class="card-body">
                    <?php if ($shipping_address): ?>
                    <address>
                        <?php echo htmlspecialchars($shipping_address['address']); ?><br>
                        <?php echo htmlspecialchars($shipping_address['city']); ?>, <?php echo htmlspecialchars($shipping_address['state']); ?> <?php echo htmlspecialchars($shipping_address['zip']); ?>
                    </address>
                    <?php else: ?>
                    <p class="text-muted">No shipping address available</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
