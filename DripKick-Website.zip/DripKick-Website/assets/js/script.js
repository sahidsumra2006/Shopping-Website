// Shopping cart functionality
document.addEventListener("DOMContentLoaded", () => {
  // Add to cart buttons
  const addToCartButtons = document.querySelectorAll(".add-to-cart")

  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productId = this.getAttribute("data-product-id")
      const quantity = document.getElementById("quantity") ? document.getElementById("quantity").value : 1

      // Show loading state
      const originalText = this.innerHTML
      this.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Adding...'
      this.disabled = true

      // Send AJAX request
      fetch("add_to_cart.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `product_id=${productId}&quantity=${quantity}`,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            // Update cart count
            const cartCount = document.getElementById("cart-count")
            if (cartCount) {
              cartCount.textContent = data.cart_count
            }

            // Show success message
            showToast("Product added to cart!", "success")
          } else {
            showToast(data.message || "Error adding product to cart", "error")
          }
        })
        .catch((error) => {
          console.error("Error:", error)
          showToast("Error adding product to cart", "error")
        })
        .finally(() => {
          // Reset button state
          this.innerHTML = originalText
          this.disabled = false
        })
    })
  })

  // Search functionality
  const searchForm = document.getElementById("search-form")
  if (searchForm) {
    searchForm.addEventListener("submit", (e) => {
      const searchInput = document.getElementById("search-input")
      if (searchInput.value.trim() === "") {
        e.preventDefault()
        searchInput.focus()
      }
    })
  }

  // Form validation
  const forms = document.querySelectorAll(".needs-validation")
  forms.forEach((form) => {
    form.addEventListener("submit", (e) => {
      if (!form.checkValidity()) {
        e.preventDefault()
        e.stopPropagation()
      }
      form.classList.add("was-validated")
    })
  })

  // Password strength indicator
  const passwordInput = document.getElementById("password")
  if (passwordInput) {
    passwordInput.addEventListener("input", function () {
      const password = this.value
      const strengthIndicator = document.getElementById("password-strength")

      if (strengthIndicator) {
        let strength = 0
        let strengthText = ""
        let strengthClass = ""

        if (password.length >= 6) strength++
        if (password.match(/[a-z]/)) strength++
        if (password.match(/[A-Z]/)) strength++
        if (password.match(/[0-9]/)) strength++
        if (password.match(/[^a-zA-Z0-9]/)) strength++

        switch (strength) {
          case 0:
          case 1:
            strengthText = "Weak"
            strengthClass = "text-danger"
            break
          case 2:
          case 3:
            strengthText = "Medium"
            strengthClass = "text-warning"
            break
          case 4:
          case 5:
            strengthText = "Strong"
            strengthClass = "text-success"
            break
        }

        strengthIndicator.textContent = strengthText
        strengthIndicator.className = strengthClass
      }
    })
  }
})

// Toast notification function
function showToast(message, type = "info") {
  // Create toast element
  const toast = document.createElement("div")
  toast.className = `toast align-items-center text-white bg-${type === "success" ? "success" : type === "error" ? "danger" : "primary"} border-0`
  toast.setAttribute("role", "alert")
  toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `

  // Add to toast container or create one
  let toastContainer = document.getElementById("toast-container")
  if (!toastContainer) {
    toastContainer = document.createElement("div")
    toastContainer.id = "toast-container"
    toastContainer.className = "toast-container position-fixed top-0 end-0 p-3"
    toastContainer.style.zIndex = "9999"
    document.body.appendChild(toastContainer)
  }

  toastContainer.appendChild(toast)

  // Initialize and show toast
  const bsToast = window.bootstrap.Toast.getOrCreateInstance(toast)
  bsToast.show()

  // Remove toast element after it's hidden
  toast.addEventListener("hidden.bs.toast", () => {
    toast.remove()
  })
}

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Image lazy loading
if ("IntersectionObserver" in window) {
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const img = entry.target
        img.src = img.dataset.src
        img.classList.remove("lazy")
        imageObserver.unobserve(img)
      }
    })
  })

  document.querySelectorAll("img[data-src]").forEach((img) => {
    imageObserver.observe(img)
  })
}

// Back to top button
const backToTopButton = document.createElement("button")
backToTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>'
backToTopButton.className = "btn btn-primary position-fixed"
backToTopButton.style.cssText =
  "bottom: 20px; right: 20px; z-index: 1000; border-radius: 50%; width: 50px; height: 50px; display: none;"
backToTopButton.setAttribute("title", "Back to top")

document.body.appendChild(backToTopButton)

window.addEventListener("scroll", () => {
  if (window.pageYOffset > 300) {
    backToTopButton.style.display = "block"
  } else {
    backToTopButton.style.display = "none"
  }
})

backToTopButton.addEventListener("click", () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  })
})
