// Shopping Cart JavaScript Functions

document.addEventListener("DOMContentLoaded", () => {
  // Add to cart functionality
  const addToCartButtons = document.querySelectorAll(".add-to-cart")
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productId = this.getAttribute("data-product-id")
      const quantityInput = document.getElementById("quantity")
      const quantity = quantityInput ? quantityInput.value : 1

      addToCart(productId, quantity)
    })
  })

  // Buy now functionality
  const buyNowButtons = document.querySelectorAll(".buy-now")
  buyNowButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const productId = this.getAttribute("data-product-id")
      const quantityInput = document.getElementById("quantity")
      const quantity = quantityInput ? quantityInput.value : 1

      buyNow(productId, quantity)
    })
  })
})

function addToCart(productId, quantity = 1) {
  const formData = new FormData()
  formData.append("product_id", productId)
  formData.append("quantity", quantity)

  fetch("add_to_cart.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        // Update cart count in header
        const cartCount = document.getElementById("cart-count")
        if (cartCount) {
          cartCount.textContent = data.cart_count
        }

        // Show success message
        showNotification(data.message, "success")
      } else {
        showNotification(data.message, "error")
      }
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred. Please try again.", "error")
    })
}

function buyNow(productId, quantity = 1) {
  // Create form and submit for buy now
  const form = document.createElement("form")
  form.method = "POST"
  form.action = "buy_now.php"

  const productInput = document.createElement("input")
  productInput.type = "hidden"
  productInput.name = "product_id"
  productInput.value = productId

  const quantityInput = document.createElement("input")
  quantityInput.type = "hidden"
  quantityInput.name = "quantity"
  quantityInput.value = quantity

  form.appendChild(productInput)
  form.appendChild(quantityInput)
  document.body.appendChild(form)
  form.submit()
}

function updateCartItem(productId, quantity) {
  const formData = new FormData()
  formData.append("action", "update")
  formData.append("product_id", productId)
  formData.append("quantity", quantity)

  fetch("cart.php", {
    method: "POST",
    body: formData,
  })
    .then(() => {
      location.reload()
    })
    .catch((error) => {
      console.error("Error:", error)
      showNotification("An error occurred. Please try again.", "error")
    })
}

function removeCartItem(productId) {
  if (confirm("Are you sure you want to remove this item from your cart?")) {
    const formData = new FormData()
    formData.append("action", "remove")
    formData.append("product_id", productId)

    fetch("cart.php", {
      method: "POST",
      body: formData,
    })
      .then(() => {
        location.reload()
      })
      .catch((error) => {
        console.error("Error:", error)
        showNotification("An error occurred. Please try again.", "error")
      })
  }
}

function showNotification(message, type = "info") {
  // Create notification element
  const notification = document.createElement("div")
  notification.className = `alert alert-${type === "success" ? "success" : "danger"} alert-dismissible fade show position-fixed`
  notification.style.cssText = "top: 20px; right: 20px; z-index: 9999; min-width: 300px;"
  notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `

  document.body.appendChild(notification)

  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove()
    }
  }, 5000)
}
