<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=track_order.php');
    exit;
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($order_id <= 0) {
    header('Location: orders.php');
    exit;
}

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: orders.php');
    exit;
}

// Parse shipping address
$shipping_address = json_decode($order['shipping_address'], true);

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <h4><i class="fas fa-shipping-fast me-2"></i>Track Order #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></h4>
                </div>
                <div class="card-body">
                    <!-- Order Status Timeline -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <h5>Order Status</h5>
                            <div class="progress mb-3" style="height: 25px;">
                                <?php
                                $status_progress = [
                                    'pending' => 25,
                                    'processing' => 50,
                                    'shipped' => 75,
                                    'delivered' => 100,
                                    'cancelled' => 0
                                ];
                                $progress = $status_progress[$order['status']] ?? 0;
                                $progress_color = $order['status'] == 'cancelled' ? 'bg-danger' : 'bg-success';
                                ?>
                                <div class="progress-bar <?php echo $progress_color; ?>" role="progressbar" 
                                     style="width: <?php echo $progress; ?>%" 
                                     aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
                                    <?php echo ucfirst($order['status']); ?>
                                </div>
                            </div>
                            
                            <!-- Status Steps -->
                            <div class="row text-center">
                                <div class="col-3">
                                    <div class="step <?php echo in_array($order['status'], ['pending', 'processing', 'shipped', 'delivered']) ? 'active' : ''; ?>">
                                        <i class="fas fa-clock fa-2x mb-2"></i>
                                        <p><small>Order Placed</small></p>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="step <?php echo in_array($order['status'], ['processing', 'shipped', 'delivered']) ? 'active' : ''; ?>">
                                        <i class="fas fa-cogs fa-2x mb-2"></i>
                                        <p><small>Processing</small></p>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="step <?php echo in_array($order['status'], ['shipped', 'delivered']) ? 'active' : ''; ?>">
                                        <i class="fas fa-truck fa-2x mb-2"></i>
                                        <p><small>Shipped</small></p>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="step <?php echo $order['status'] == 'delivered' ? 'active' : ''; ?>">
                                        <i class="fas fa-check-circle fa-2x mb-2"></i>
                                        <p><small>Delivered</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Order Information -->
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Order Information</h5>
                            <p><strong>Order Date:</strong> <?php echo date('F j, Y g:i A', strtotime($order['created_at'])); ?></p>
                            <p><strong>Payment Method:</strong> 
                                <span class="badge bg-<?php echo $order['payment_method'] == 'cod' ? 'warning' : 'info'; ?>">
                                    <?php echo strtoupper($order['payment_method']); ?>
                                </span>
                            </p>
                            <p><strong>Total Amount:</strong> <span class="text-success">$<?php echo number_format($order['total'], 2); ?></span></p>
                            
                            <?php if ($order['status'] == 'pending'): ?>
                            <div class="mt-3">
                                <form method="POST" action="cancel_order.php" onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <button type="submit" class="btn btn-outline-danger btn-sm">
                                        <i class="fas fa-times me-1"></i>Cancel Order
                                    </button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <h5>Shipping Address</h5>
                            <?php if ($shipping_address): ?>
                            <address>
                                <strong><?php echo htmlspecialchars($shipping_address['name'] ?? 'N/A'); ?></strong><br>
                                <?php if (isset($shipping_address['phone'])): ?>
                                Phone: <?php echo htmlspecialchars($shipping_address['phone']); ?><br>
                                <?php endif; ?>
                                <?php echo htmlspecialchars($shipping_address['address'] ?? 'N/A'); ?><br>
                                <?php echo htmlspecialchars($shipping_address['city'] ?? 'N/A'); ?>, 
                                <?php echo htmlspecialchars($shipping_address['state'] ?? 'N/A'); ?> 
                                <?php echo htmlspecialchars($shipping_address['zip'] ?? 'N/A'); ?>
                            </address>
                            <?php else: ?>
                            <p class="text-muted">No shipping address available</p>
                            <?php endif; ?>
                            
                            <div class="mt-3">
                                <h6>Estimated Delivery</h6>
                                <?php
                                $estimated_date = date('F j, Y', strtotime($order['created_at'] . ' +5 days'));
                                ?>
                                <p class="text-primary"><?php echo $estimated_date; ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <a href="orders.php" class="btn btn-primary me-2">
                            <i class="fas fa-list me-2"></i>View All Orders
                        </a>
                        <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn btn-outline-primary">
                            <i class="fas fa-eye me-2"></i>View Order Details
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.step {
    opacity: 0.5;
    transition: opacity 0.3s;
}
.step.active {
    opacity: 1;
    color: #28a745;
}
</style>

<?php include 'includes/footer.php'; ?>
