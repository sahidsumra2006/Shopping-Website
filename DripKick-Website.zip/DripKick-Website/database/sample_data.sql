-- Updated categories to include Men, Women, Children
INSERT INTO categories (name, description, icon) VALUES
('Men', 'Men\'s clothing and accessories', 'male'),
('Women', 'Women\'s clothing and accessories', 'female'),
('Children', 'Children\'s clothing and accessories', 'child');

-- Insert admin user (username: Admin, password: Admin@123)
INSERT INTO admin (username, password) VALUES
('Admin', '$2y$10$YourHashedPasswordHere'); -- This will be properly hashed

-- Updated sample products for Men, Women, Children categories
INSERT INTO products (name, description, price, stock, category_id, image, featured) VALUES
-- Men's Products
('Men\'s Casual Shirt', 'Comfortable cotton casual shirt for men', 29.99, 100, 1, 'mens-shirt.jpg', TRUE),
('Men\'s Jeans', 'Classic fit denim jeans for men', 49.99, 80, 1, 'mens-jeans.jpg', TRUE),
('Men\'s Sneakers', 'Stylish sneakers for everyday wear', 79.99, 60, 1, 'mens-sneakers.jpg', FALSE),
('Men\'s Watch', 'Elegant wristwatch for men', 199.99, 40, 1, 'mens-watch.jpg', TRUE),
('Men\'s Jacket', 'Warm winter jacket for men', 89.99, 50, 1, 'mens-jacket.jpg', FALSE),

-- Women's Products
('Women\'s Dress', 'Elegant evening dress for women', 69.99, 70, 2, 'womens-dress.jpg', TRUE),
('Women\'s Handbag', 'Stylish leather handbag', 89.99, 90, 2, 'womens-handbag.jpg', TRUE),
('Women\'s Heels', 'Comfortable high heels for women', 59.99, 85, 2, 'womens-heels.jpg', FALSE),
('Women\'s Blouse', 'Professional blouse for office wear', 39.99, 120, 2, 'womens-blouse.jpg', TRUE),
('Women\'s Jewelry Set', 'Beautiful jewelry set with necklace and earrings', 149.99, 30, 2, 'womens-jewelry.jpg', FALSE),

-- Children's Products
('Kids T-Shirt', 'Colorful t-shirt for children', 15.99, 150, 3, 'kids-tshirt.jpg', TRUE),
('Kids Shoes', 'Comfortable shoes for active kids', 35.99, 100, 3, 'kids-shoes.jpg', TRUE),
('Kids Backpack', 'Fun and functional backpack for school', 25.99, 80, 3, 'kids-backpack.jpg', FALSE),
('Kids Dress', 'Pretty dress for special occasions', 29.99, 60, 3, 'kids-dress.jpg', FALSE),
('Kids Toy Set', 'Educational toy set for children', 45.99, 40, 3, 'kids-toys.jpg', TRUE);

-- Insert sample user (password is 'password123')
INSERT INTO users (name, email, password) VALUES
('John Doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('Jane Smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Insert sample orders
INSERT INTO orders (user_id, total, status, shipping_address, payment_method) VALUES
(1, 79.98, 'delivered', '{"address": "123 Main St", "city": "New York", "state": "NY", "zip": "10001"}', 'cod'),
(2, 69.99, 'processing', '{"address": "456 Oak Ave", "city": "Los Angeles", "state": "CA", "zip": "90210"}', 'online');

-- Insert sample order items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 1, 29.99),
(1, 2, 1, 49.99),
(2, 6, 1, 69.99);

-- Insert sample reviews
INSERT INTO reviews (user_id, product_id, rating, comment) VALUES
(1, 1, 5, 'Great quality shirt, very comfortable!'),
(2, 6, 4, 'Beautiful dress, perfect for special occasions'),
(1, 11, 5, 'My kids love this t-shirt, great quality!');
