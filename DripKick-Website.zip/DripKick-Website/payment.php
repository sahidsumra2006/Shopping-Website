<?php
session_start();
include 'config/database.php';

// Redirect if cart is empty
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=payment.php');
    exit;
}

// Get user details for pre-filling form
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

$cart = $_SESSION['cart'];
$cart_total = 0;
foreach ($cart as $item) {
    $cart_total += $item['price'] * $item['quantity'];
}
$shipping = 5.00;
$tax = $cart_total * 0.08;
$total = $cart_total + $shipping + $tax;

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $state = trim($_POST['state']);
    $zip = trim($_POST['zip']);
    $payment_method = $_POST['payment_method'];
    
    // Validation
    if (empty($name) || empty($phone) || empty($address) || empty($city) || empty($state) || empty($zip)) {
        $error = 'Please fill in all required fields';
    } else {
        $payment_screenshot = null;
        
        // Handle screenshot upload for online payment
        if ($payment_method == 'online' && isset($_FILES['payment_screenshot']) && $_FILES['payment_screenshot']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $file_type = $_FILES['payment_screenshot']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                $file_extension = pathinfo($_FILES['payment_screenshot']['name'], PATHINFO_EXTENSION);
                $payment_screenshot = 'payment_' . uniqid() . '.' . $file_extension;
                $upload_path = 'assets/images/payments/' . $payment_screenshot;
                
                // Create directory if it doesn't exist
                if (!file_exists('assets/images/payments/')) {
                    mkdir('assets/images/payments/', 0777, true);
                }
                
                if (!move_uploaded_file($_FILES['payment_screenshot']['tmp_name'], $upload_path)) {
                    $error = 'Failed to upload payment screenshot';
                }
            } else {
                $error = 'Please upload a valid image file (JPEG, PNG, or GIF)';
            }
        } elseif ($payment_method == 'online') {
            $error = 'Please upload payment screenshot for online payment';
        }
        
        if (empty($error)) {
            try {
                $pdo->beginTransaction();
                
                // Create order
                $stmt = $pdo->prepare("INSERT INTO orders (user_id, total, status, shipping_address, payment_method, payment_status, payment_screenshot, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                $shipping_address = json_encode([
                    'name' => $name,
                    'phone' => $phone,
                    'address' => $address, 
                    'city' => $city, 
                    'state' => $state, 
                    'zip' => $zip
                ]);
                
                $payment_status = ($payment_method == 'cod') ? 'pending' : 'pending';
                $order_status = 'pending';
                
                $stmt->execute([$_SESSION['user_id'], $total, $order_status, $shipping_address, $payment_method, $payment_status, $payment_screenshot]);
                $order_id = $pdo->lastInsertId();
                
                // Add order items
                foreach ($cart as $item) {
                    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$order_id, $item['id'], $item['quantity'], $item['price']]);
                }
                
                $pdo->commit();
                
                // Clear cart and buy now flag
                $_SESSION['cart'] = [];
                unset($_SESSION['buy_now']);
                
                header("Location: order-success.php?order_id=$order_id");
                exit;
                
            } catch (Exception $e) {
                $pdo->rollBack();
                $error = 'Order processing failed. Please try again.';
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-12">
            <h2 class="text-center mb-4">Payment</h2>
            
            <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-lg-8">
                    <form method="POST" enctype="multipart/form-data">
                        <!-- Customer Information -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5><i class="fas fa-user me-2"></i>Customer Information</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Full Name *</label>
                                        <input type="text" class="form-control" name="name" required 
                                               value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">Phone Number *</label>
                                        <input type="tel" class="form-control" name="phone" required 
                                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Shipping Address -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5><i class="fas fa-shipping-fast me-2"></i>Shipping Address</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12 mb-3">
                                        <label class="form-label">Address *</label>
                                        <input type="text" class="form-control" name="address" required 
                                               value="<?php echo htmlspecialchars($user['address'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label">City *</label>
                                        <input type="text" class="form-control" name="city" required 
                                               value="<?php echo htmlspecialchars($user['city'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">State *</label>
                                        <input type="text" class="form-control" name="state" required 
                                               value="<?php echo htmlspecialchars($user['state'] ?? ''); ?>">
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label class="form-label">ZIP Code *</label>
                                        <input type="text" class="form-control" name="zip" required 
                                               value="<?php echo htmlspecialchars($user['zip'] ?? ''); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Payment Method -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5><i class="fas fa-credit-card me-2"></i>Payment Method</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="radio" name="payment_method" id="cod" value="cod" checked>
                                            <label class="form-check-label" for="cod">
                                                <i class="fas fa-money-bill-wave text-success me-2"></i>
                                                <strong>Cash on Delivery (COD)</strong>
                                                <br><small class="text-muted">Pay when you receive your order</small>
                                            </label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="radio" name="payment_method" id="online" value="online">
                                            <label class="form-check-label" for="online">
                                                <i class="fas fa-qrcode text-primary me-2"></i>
                                                <strong>Online Payment</strong>
                                                <br><small class="text-muted">Pay now using QR code</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Online Payment Section -->
                                <div id="online-payment-section" style="display: none;">
                                    <hr>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <h6>Scan QR Code to Pay</h6>
                                            <div class="text-center p-3 border rounded">
                                                <img src="/placeholder.svg?height=200&width=200" 
                                                     alt="Payment QR Code" class="img-fluid" style="max-width: 200px;">
                                                <p class="mt-2 mb-0"><strong>Total: $<?php echo number_format($total, 2); ?></strong></p>
                                                <small class="text-muted">Scan with your payment app</small>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <h6>Upload Payment Screenshot *</h6>
                                            <input type="file" class="form-control" name="payment_screenshot" accept="image/*" onchange="previewPaymentScreenshot(this)">
                                            <div class="form-text">Upload screenshot of successful payment</div>
                                            <div id="screenshot-preview" class="mt-2" style="display: none;">
                                                <img id="screenshot-image" src="#" alt="Payment Screenshot Preview" class="img-thumbnail" style="max-width: 200px;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="cart.php" class="btn btn-secondary me-md-2">
                                <i class="fas fa-arrow-left me-2"></i>Back to Cart
                            </a>
                            <button type="submit" class="btn btn-success btn-lg">
                                <i class="fas fa-check me-2"></i>Place Order
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Order Summary -->
                <div class="col-lg-4">
                    <div class="card sticky-top">
                        <div class="card-header">
                            <h5><i class="fas fa-receipt me-2"></i>Order Summary</h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($cart as $item): ?>
                            <div class="d-flex justify-content-between mb-2">
                                <span><?php echo htmlspecialchars($item['name']); ?> x<?php echo $item['quantity']; ?></span>
                                <span>$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></span>
                            </div>
                            <?php endforeach; ?>
                            
                            <hr>
                            <div class="d-flex justify-content-between">
                                <span>Subtotal:</span>
                                <span>$<?php echo number_format($cart_total, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Shipping:</span>
                                <span>$<?php echo number_format($shipping, 2); ?></span>
                            </div>
                            <div class="d-flex justify-content-between">
                                <span>Tax:</span>
                                <span>$<?php echo number_format($tax, 2); ?></span>
                            </div>
                            <hr>
                            <div class="d-flex justify-content-between">
                                <strong>Total:</strong>
                                <strong class="text-primary">$<?php echo number_format($total, 2); ?></strong>
                            </div>
                            
                            <div class="mt-3 p-3 bg-light rounded">
                                <small class="text-muted">
                                    <i class="fas fa-shield-alt me-1"></i>
                                    Your payment information is secure and encrypted.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Toggle online payment section
document.addEventListener('DOMContentLoaded', function() {
    const codRadio = document.getElementById('cod');
    const onlineRadio = document.getElementById('online');
    const onlineSection = document.getElementById('online-payment-section');
    const screenshotInput = document.querySelector('input[name="payment_screenshot"]');
    
    function togglePaymentSection() {
        if (onlineRadio.checked) {
            onlineSection.style.display = 'block';
            screenshotInput.required = true;
        } else {
            onlineSection.style.display = 'none';
            screenshotInput.required = false;
        }
    }
    
    codRadio.addEventListener('change', togglePaymentSection);
    onlineRadio.addEventListener('change', togglePaymentSection);
    
    // Initial state
    togglePaymentSection();
});

function previewPaymentScreenshot(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('screenshot-image').src = e.target.result;
            document.getElementById('screenshot-preview').style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>

<?php include 'includes/footer.php'; ?>
