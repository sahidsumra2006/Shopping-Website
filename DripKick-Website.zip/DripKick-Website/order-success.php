<?php
session_start();
include 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$order_id = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;

if ($order_id <= 0) {
    header('Location: index.php');
    exit;
}

// Get order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$order_id, $_SESSION['user_id']]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: index.php');
    exit;
}

include 'includes/header.php';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="card">
                <div class="card-body py-5">
                    <i class="fas fa-check-circle fa-4x text-success mb-4"></i>
                    <h2 class="text-success mb-3">Order Placed Successfully!</h2>
                    <p class="lead mb-4">Thank you for your order. We'll process it shortly.</p>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>Order Details</h5>
                            <p><strong>Order ID:</strong> #<?php echo str_pad($order['id'], 6, '0', STR_PAD_LEFT); ?></p>
                            <p><strong>Total:</strong> $<?php echo number_format($order['total'], 2); ?></p>
                            <p><strong>Payment Method:</strong> 
                                <span class="badge bg-<?php echo $order['payment_method'] == 'cod' ? 'warning' : 'info'; ?>">
                                    <?php echo strtoupper($order['payment_method']); ?>
                                </span>
                            </p>
                            <p><strong>Status:</strong> 
                                <span class="badge bg-warning"><?php echo ucfirst($order['status']); ?></span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <h5>What's Next?</h5>
                            <?php if ($order['payment_method'] == 'cod'): ?>
                            <p><i class="fas fa-truck text-primary"></i> Your order will be processed and shipped soon.</p>
                            <p><i class="fas fa-money-bill-wave text-success"></i> Pay when you receive your order.</p>
                            <?php else: ?>
                            <p><i class="fas fa-clock text-warning"></i> We're verifying your payment.</p>
                            <p><i class="fas fa-check text-success"></i> Order will be processed after payment confirmation.</p>
                            <?php endif; ?>
                            <p><strong>Estimated delivery:</strong> 3-5 business days</p>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <a href="orders.php" class="btn btn-primary me-2">
                            <i class="fas fa-list me-2"></i>View My Orders
                        </a>
                        <a href="products.php" class="btn btn-outline-primary">
                            <i class="fas fa-shopping-bag me-2"></i>Continue Shopping
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
