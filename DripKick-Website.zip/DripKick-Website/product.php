<?php
session_start();
include 'config/database.php';
include 'includes/header.php';

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: products.php');
    exit;
}

// Get product details
$stmt = $pdo->prepare("SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: products.php');
    exit;
}

// Get related products
$stmt = $pdo->prepare("SELECT * FROM products WHERE category_id = ? AND id != ? LIMIT 4");
$stmt->execute([$product['category_id'], $product_id]);
$related_products = $stmt->fetchAll();

// Check for error messages
$error_message = '';
if (isset($_GET['error'])) {
    switch ($_GET['error']) {
        case 'insufficient_stock':
            $error_message = 'Sorry, there is not enough stock available for the requested quantity.';
            break;
    }
}
?>

<div class="container py-4">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            <li class="breadcrumb-item"><a href="products.php">Products</a></li>
            <li class="breadcrumb-item active"><?php echo htmlspecialchars($product['name']); ?></li>
        </ol>
    </nav>
    
    <?php if ($error_message): ?>
    <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-lg-6">
            <img src="assets/images/products/<?php echo $product['image']; ?>" class="img-fluid rounded" alt="<?php echo htmlspecialchars($product['name']); ?>">
        </div>
        <div class="col-lg-6">
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <p class="text-muted mb-3">Category: <?php echo htmlspecialchars($product['category_name']); ?></p>
            <h3 class="text-primary mb-4">$<?php echo number_format($product['price'], 2); ?></h3>
            
            <div class="mb-4">
                <h5>Description</h5>
                <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            </div>
            
            <div class="mb-4">
                <label class="form-label">Quantity</label>
                <div class="input-group" style="width: 150px;">
                    <button class="btn btn-outline-secondary" type="button" id="decrease-qty">-</button>
                    <input type="number" class="form-control text-center" id="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>">
                    <button class="btn btn-outline-secondary" type="button" id="increase-qty">+</button>
                </div>
                <small class="text-muted">Stock: <?php echo $product['stock']; ?> available</small>
            </div>
            
            <div class="d-grid gap-2 d-md-flex">
                <!-- Added Buy Now button alongside Add to Cart -->
                <button class="btn btn-success btn-lg me-md-2 buy-now" data-product-id="<?php echo $product['id']; ?>">
                    <i class="fas fa-bolt"></i> Buy Now
                </button>
                <button class="btn btn-primary btn-lg me-md-2 add-to-cart" data-product-id="<?php echo $product['id']; ?>">
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>
                <button class="btn btn-outline-secondary btn-lg">
                    <i class="fas fa-heart"></i> Add to Wishlist
                </button>
            </div>
        </div>
    </div>
    
    <!-- Related Products -->
    <?php if (!empty($related_products)): ?>
    <div class="mt-5">
        <h3>Related Products</h3>
        <div class="row">
            <?php foreach ($related_products as $related): ?>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100">
                    <img src="assets/images/products/<?php echo $related['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($related['name']); ?>">
                    <div class="card-body d-flex flex-column">
                        <h6 class="card-title"><?php echo htmlspecialchars($related['name']); ?></h6>
                        <div class="mt-auto">
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary">$<?php echo number_format($related['price'], 2); ?></span>
                                <div>
                                    <a href="product.php?id=<?php echo $related['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                    <button class="btn btn-sm btn-primary add-to-cart" data-product-id="<?php echo $related['id']; ?>">Add to Cart</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('decrease-qty').addEventListener('click', function() {
    const qtyInput = document.getElementById('quantity');
    const currentQty = parseInt(qtyInput.value);
    if (currentQty > 1) {
        qtyInput.value = currentQty - 1;
    }
});

document.getElementById('increase-qty').addEventListener('click', function() {
    const qtyInput = document.getElementById('quantity');
    const currentQty = parseInt(qtyInput.value);
    const maxQty = parseInt(qtyInput.max);
    if (currentQty < maxQty) {
        qtyInput.value = currentQty + 1;
    }
});
</script>

<?php include 'includes/footer.php'; ?>
